const Discord = require("discord.js");

exports.run = async (client, message, args) => {
  if (!message.member.hasPermission("MANAGE_NICKNAMES"))
    return message.channel.send(
      `**Bu komudu kullanabilmek için *KAYIT GÖREVLİSİ* olman gerek!**`
    );
  let member = message.mentions.members.first();
  let isim = args.slice(1).join(" ");
  let yas = args.slice(1).join(" ");
  if (!member) return message.channel.send("**Lütfen kız olarak kayıt edilecek kişiyi etiketle!**");
  member.setNickname(`${isim}`);
  member.removeRole('819179280696475660')
  member.addRole('819179068251176971')
  member.addRole('819178772267270168')
const embed = new Discord.RichEmbed()


      .setDescription(`${member.user} **Adlı kullanıcı Başarıyla *Kız* olarak kayıt edildive** <@&819178772267270168> **adlı rol Başarıyla verildi!**`)
      .setFooter(`İşlemi yapan görevli: ${message.author.username}`)
client.channels.get('819181922826715156').send(embed)
};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["k"],
  permLevel: 0
};
exports.help = {
  name: "kız",
  description: "",
  usage: "kız"
};